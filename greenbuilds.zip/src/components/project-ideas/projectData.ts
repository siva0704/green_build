
export const projectImages = [
  "/lovable-uploads/0455a043-e470-446c-a470-92a5e38ba50a.png",
  "/lovable-uploads/33a27c58-96ce-4a7d-b471-e184c38bced6.png",
  "/lovable-uploads/8f2c1fd5-0026-4260-81d9-069a1d7910c2.png",
  "/lovable-uploads/777d28e8-12c0-4135-9d6b-2d38b4343e9e.png",
  "/lovable-uploads/07961ee8-69b5-40b2-931d-5e7d847d875a.png",
  "/lovable-uploads/9fade70a-4b5a-49c6-b9d7-1cb93a453baa.png",
  "/lovable-uploads/d6e633c0-418c-4972-a92c-171010ac79d5.png",
  "/lovable-uploads/6e489563-5da0-464f-84d0-3b598643dfd5.png"
];

export const projectTitles = [
  "Modern Villa",
  "Luxury Apartment",
  "Contemporary Home",
  "Classic Design",
  "Elegant Interior",
  "Smart Home",
  "Premium Finish",
  "Spacious Layout"
];
