
export const projectMedia = [
  { url: "/lovable-uploads/30e77ea3-aa20-405f-b85d-08c57c1be77b.png", type: 'image' as const },
  { url: "1100809022", type: 'vimeo' as const, title: "Sustainable Living: Inside a Green Build Home" },
  { url: "/lovable-uploads/24a18a28-c78a-4d07-8d44-7ae98244a1df.png", type: 'image' as const },
  { url: "1100808750", type: 'vimeo' as const, title: "From Ground Up: The Art of Green Building" },
  { url: "/lovable-uploads/b5f78dc9-860e-4d1a-bae6-32b7c74f4c4e.png", type: 'image' as const },
  { url: "1100807866", type: 'vimeo' as const, title: "Building Tomorrow: The Green Construction Journey" },
  { url: "/lovable-uploads/641d35a3-8f83-4230-9e0f-a81e761076be.png", type: 'image' as const },
  { url: "/lovable-uploads/9308c6fe-f8f8-40ad-9859-bf62667dfa06.png", type: 'image' as const },
  { url: "/lovable-uploads/c5da3f15-2ae0-4573-b9ab-3bd1b45ee353.png", type: 'image' as const }
];
